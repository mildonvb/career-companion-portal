package com.example.Mildon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MildonApplicationTests {

	@Test
	void contextLoads() {
	}

}
