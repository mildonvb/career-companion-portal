package com.example.Mildon.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Mildon.model.Mentor;

@Repository
public interface MentorRepository extends JpaRepository<Mentor, Long> {
	Mentor findByEmail(String email);
	boolean existsByEmail(String email);  // ✅ Add this method
    List<Mentor> findByFullNameContainingAndSpecializationContaining(String fullName, String specialization);
    Optional<Mentor> findByResetToken(String resetToken);


}
