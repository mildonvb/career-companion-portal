package com.example.Mildon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Mildon.repository.AdminRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public boolean isValidAdmin(String email) {
        return adminRepository.existsByEmail(email);  // Adjust this according to your repository's method
    }
}
