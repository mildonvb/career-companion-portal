package com.example.Mildon.dto;

public class AuthResponse {
    private String token;

    public AuthResponse(String token) { // Constructor with String parameter
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}
