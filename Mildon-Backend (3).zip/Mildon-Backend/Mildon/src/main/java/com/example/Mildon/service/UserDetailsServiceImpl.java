package com.example.Mildon.service;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.Mildon.model.Admin;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.repository.AdminRepository;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.StudentRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Student student = studentRepository.findByEmail(email);
        if (student != null) {
            return new User(student.getEmail(), student.getPassword(), new ArrayList<>());
        }

        Mentor mentor = mentorRepository.findByEmail(email);
        if (mentor != null) {
            return new User(mentor.getEmail(), mentor.getPassword(), new ArrayList<>());
        }

        Admin admin = adminRepository.findByEmail(email);
        if (admin != null) {
            return new User(admin.getEmail(), admin.getPassword(), new ArrayList<>());
        }

        throw new UsernameNotFoundException("User not found with email: " + email);
    }

}
