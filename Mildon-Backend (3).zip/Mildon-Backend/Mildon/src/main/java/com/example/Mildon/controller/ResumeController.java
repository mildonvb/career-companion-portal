package com.example.Mildon.controller;

import com.example.Mildon.model.Resume;
import com.example.Mildon.repository.ResumeRepository;
import com.example.Mildon.service.ResourceNotFoundException;
import com.example.Mildon.service.ResumeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/resumes")
@CrossOrigin(origins = "*")
public class ResumeController {

    @Autowired
    private ResumeService resumeService;
    @Autowired
    private ResumeRepository resumeRepository;

    // Upload Resume (Student)
    @PostMapping("/upload/{studentId}")
    public ResponseEntity<?> uploadResume(@PathVariable Long studentId, @RequestParam("file") MultipartFile file) {
        try {
            Resume resume = resumeService.uploadResume(studentId, file);
            return ResponseEntity.ok(resume);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Error uploading resume: " + e.getMessage());
        }
    }
    
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Resume>> getStudentResumes(@PathVariable Long studentId) {
        List<Resume> resumes = resumeService.getStudentResumes(studentId);
        return ResponseEntity.ok(resumes);
    }

    @GetMapping("/mentor/{mentorId}")
    public ResponseEntity<List<Resume>> getResumesForMentor(@PathVariable Long mentorId) {
        List<Resume> resumes = resumeService.getResumesForMentor(mentorId);
        return ResponseEntity.ok(resumes);
    }

    @PutMapping("/feedback/{resumeId}")
    public ResponseEntity<String> provideFeedback(
            @PathVariable Long resumeId,
            @RequestBody Map<String, String> request,
            @RequestHeader("userId") Long loggedInMentorId) {

        Resume resume = resumeRepository.findById(resumeId)
                .orElseThrow(() -> new ResourceNotFoundException("Resume not found"));

        // Ensure only the assigned mentor can provide feedback
        if (!resume.getMentorId().equals(loggedInMentorId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You are not assigned to this student.");
        }

        resume.setFeedback(request.get("feedback"));
        resumeRepository.save(resume);
        
        return ResponseEntity.ok("Feedback saved successfully.");
    }


}
