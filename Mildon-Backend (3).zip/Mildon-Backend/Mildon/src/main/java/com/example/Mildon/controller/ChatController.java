package com.example.Mildon.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.*;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import com.example.Mildon.model.ChatMessage;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.repository.ChatMessageRepository;
import com.example.Mildon.service.ChatService;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {

    @Autowired
    private ChatService chatService;

    @GetMapping("/messages/{senderId}/{receiverId}")
    public List<ChatMessage> getChatMessages(@PathVariable String senderId, @PathVariable String receiverId) {
        return chatService.getMessagesBetweenUsers(senderId, receiverId);
    }

    @PostMapping("/send")
    public ChatMessage sendMessage(@RequestBody ChatMessage message) {
        message.setTimestamp(LocalDateTime.now());
        return chatService.saveMessage(message);
    }

    @GetMapping("/assigned-students/{mentorId}")
    public List<Student> getAssignedStudents(@PathVariable String mentorId) {
        return chatService.getStudentsForMentor(mentorId);
    }

    @GetMapping("/assigned-mentor/{studentId}")
    public Mentor getAssignedMentor(@PathVariable String studentId) {
        return chatService.getMentorForStudent(studentId);
    }
}

