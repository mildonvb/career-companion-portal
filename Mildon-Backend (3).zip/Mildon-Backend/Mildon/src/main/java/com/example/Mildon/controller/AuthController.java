package com.example.Mildon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

//import com.example.Mildon.service.AuthService;
import com.example.Mildon.dto.AuthResponse;
import com.example.Mildon.dto.ForgotPasswordRequest;
import com.example.Mildon.dto.JwtResponse;
import com.example.Mildon.dto.LoginRequest;
import com.example.Mildon.dto.MentorRequestDto;
import com.example.Mildon.dto.RegisterRequest;
import com.example.Mildon.dto.ResetPasswordRequest;
import com.example.Mildon.dto.ResponseMessage;
import com.example.Mildon.dto.StudentDTO;
import com.example.Mildon.model.Admin;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.service.AuthService;
import com.example.Mildon.service.EmailService;
import com.example.Mildon.service.MentorService;
//import com.example.Mildon.service.StudentMentorService;
import com.example.Mildon.service.StudentService;

import jakarta.transaction.Transactional;

import com.example.Mildon.repository.AdminRepository;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.StudentMentorRepository;
import com.example.Mildon.repository.StudentRepository;
import com.example.Mildon.security.JwtTokenUtil;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {
          
//    @Autowired private AuthService authService;

    @Autowired
    private StudentService studentService;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private StudentRepository studentRepository; 
    
    
    
    
    @PostMapping("/signupstudent")
    public ResponseEntity<String> registerStudent(@RequestBody Student student) {
        try {
            // Check if the email already exists in the database
            if (studentRepository.existsByEmail(student.getEmail())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email already exists");
            }

            // Call service to save the student
            boolean isSaved = studentService.registerStudent(student);
            
            if (isSaved) {
                return ResponseEntity.ok("Student successfully registered");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add user");
            }
        } catch (Exception e) {
            // Log the exception for debugging
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred during registration");
        }
    }



    @Autowired
    private JwtTokenUtil jwtTokenUtil;



    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public Map<String, Object> authenticateUser(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        // Debugging: Print email being checked
        System.out.println("Attempting login for: " + email);

        // Check Student
        Student student = studentRepository.findByEmail(email);
        if (student != null) {
            System.out.println("Student Found: " + student.getEmail());
            System.out.println("Stored Hashed Password: " + student.getPassword());
            System.out.println("Password Match: " + passwordEncoder.matches(password, student.getPassword()));

            if (passwordEncoder.matches(password, student.getPassword())) {
                String token = jwtTokenUtil.generateToken(email);
                return generateSuccessResponse(student.getId(),student.getFullName(), student.getEmail(), "student", token);
            }
        }

        // Check Mentor
        Mentor mentor = mentorRepository.findByEmail(email);
        if (mentor != null) {
            System.out.println("Mentor Found: " + mentor.getEmail());
            System.out.println("Stored Hashed Password: " + mentor.getPassword());
            System.out.println("Password Match: " + passwordEncoder.matches(password, mentor.getPassword()));

            if (passwordEncoder.matches(password, mentor.getPassword())) {
                String token = jwtTokenUtil.generateToken(email);
                return generateSuccessResponse(mentor.getId(),mentor.getFullName(), mentor.getEmail(), "mentor", token);
            }
        }

        // Check Admin
        Admin admin = adminRepository.findByEmail(email);
        if (admin != null) {
            System.out.println("Admin Found: " + admin.getEmail());
            System.out.println("Stored Hashed Password: " + admin.getPassword());
            System.out.println("Password Match: " + passwordEncoder.matches(password, admin.getPassword()));

            if (passwordEncoder.matches(password, admin.getPassword())) {
                String token = jwtTokenUtil.generateToken(email);
                return generateSuccessResponse(admin.getId(),admin.getFullName(), admin.getEmail(), "admin", token);
            }
        }

        // If no user matched
        System.out.println("Login failed for: " + email);
        return generateErrorResponse("Invalid email or password");
    }

    private Map<String, Object> generateSuccessResponse(Long userId,String fullName,  String email, String role, String token) {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("token", token);
        response.put("userId", userId);
        response.put("username", email);
        response.put("fullName", fullName);  // Add fullName here

        response.put("role", role);
        return response;
    }

    private Map<String, Object> generateErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "error");
        response.put("errorMessage", message);
        return response;
    }

    
    
    
    
    
    
    
    
    
    @Autowired
    private MentorService mentorService; 

    @PostMapping("/register-mentors")  // This must match frontend API URL
    public ResponseEntity<?> registerMentor(@RequestBody MentorRequestDto mentorDto) {
        try {
            mentorService.registerMentor(mentorDto);  // Ensure this method exists
            return ResponseEntity.ok("Mentor registered successfully!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }
    
    
    
    

    
    
    
    
    
    
    
    
    
   
    @GetMapping("/unassigned")
    public ResponseEntity<List<Student>> getUnassignedStudents() {
        return ResponseEntity.ok(studentService.getUnassignedStudents());
    }

    @GetMapping("/getallstudents") // Unique endpoint for students
    public ResponseEntity<List<Student>> getAllStudents() {
        return ResponseEntity.ok(studentService.getAllStudents());
    }


    @PostMapping("/assign-mentor/{studentId}/{mentorId}")
    public ResponseEntity<?> assignOrUpdateMentor(@PathVariable Long studentId, @PathVariable Long mentorId) {
        try {
            studentService.assignOrUpdateMentor(studentId, mentorId);
            return ResponseEntity.ok("✅ Mentor assigned/updated successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("❌ Error: " + e.getMessage());
        }
    }



    @DeleteMapping("/remove-mentor/{studentId}")
    public ResponseEntity<String> removeMentor(@PathVariable Long studentId) {
        studentService.removeMentor(studentId);
        return ResponseEntity.ok("✅ Mentor removed successfully.");
    }

    
    
    


    @GetMapping("/getallmentors") // Unique endpoint for students
    public ResponseEntity<List<Mentor>> getAllMentors() {
        return ResponseEntity.ok(mentorService.getAllMentors());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Mentor>> searchMentors(@RequestParam String name, @RequestParam String specialization) {
        return ResponseEntity.ok(mentorService.searchMentors(name, specialization));
    }
    
    
    // Fetch mentor details by ID
    @GetMapping("/fetchmentor/{id}")
    public ResponseEntity<Mentor> getMentorById(@PathVariable Long id) {
        return ResponseEntity.ok(mentorService.getMentorById(id));
    }

    // Update mentor details
    @PutMapping("/updatementor/{id}")
    public ResponseEntity<String> updateMentor(@PathVariable Long id, @RequestBody Mentor updatedMentor) {
        mentorService.updateMentor(id, updatedMentor);
        return ResponseEntity.ok("Mentor updated successfully!");
    }
    
    @DeleteMapping("/deletementor/{id}")
    public ResponseEntity<String> deleteMentor(@PathVariable Long id) {
        mentorService.deleteMentor(id);
        return ResponseEntity.ok("Mentor deleted successfully.");
    }

    
//    @PostMapping("/register")
//    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest request) {
//        return ResponseEntity.ok(authService.register(request));
//    }
//
//    @PostMapping("/login")
//    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
//        return ResponseEntity.ok(authService.login(request));
//    }
    
    
    @GetMapping("/getallstudentsmentor")
    public List<StudentDTO> getAllStudentsWithMentors() {
        return studentService.getAllStudentsWithMentors();
    }
    
    
    
    
   
    @Autowired
    private AuthService authService;

    // ✅ Forgot Password - Send Reset Email
    @PostMapping("/forgot-password")
    public ResponseEntity<ResponseMessage> forgotPassword(@RequestBody ForgotPasswordRequest request) {
        try {
            authService.forgotPassword(request.getEmail());  // Call the service method
            return ResponseEntity.ok(new ResponseMessage("Password reset link sent to your email."));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(e.getMessage()));
        }
    }

    // ✅ Reset Password
    @PostMapping("/reset-password")
    public ResponseEntity<ResponseMessage> resetPassword(@RequestBody ResetPasswordRequest request) {
        try {
            authService.resetPassword(request.getToken(), request.getNewPassword());  // Call the service method
            return ResponseEntity.ok(new ResponseMessage("Password reset successfully."));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(e.getMessage()));
        }
    }


    @GetMapping("/{mentorId}/mentorassignedstudents")
    public ResponseEntity<List<Student>> getAssignedStudents(@PathVariable Long mentorId) {
        List<Student> students = mentorService.getAssignedStudents(mentorId);
        return ResponseEntity.ok(students);
    }

   
  
}
