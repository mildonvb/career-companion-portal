package com.example.Mildon.service;

import com.example.Mildon.model.Admin;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.repository.AdminRepository;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

	
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private EmailService emailService;  // Assuming email service is already implemented

    // ✅ 4️⃣ Forgot Password - Generate and Send Reset Token
    public void forgotPassword(String email) {
        Admin admin = adminRepository.findByEmail(email);
        if (admin != null) {
            generateResetTokenForUser(admin);
            return;
        }

        Mentor mentor = mentorRepository.findByEmail(email);
        if (mentor != null) {
            generateResetTokenForUser(mentor);
            return;
        }

        Student student = studentRepository.findByEmail(email);
        if (student != null) {
            generateResetTokenForUser(student);
            return;
        }

        throw new RuntimeException("❌ Email not found in any user records.");
    }

    private void sendResetEmail(String email, String token) {
        String resetLink1 = "http://localhost:3000/reset-password?token=" + token;
        String resetLink2 = "http://192.168.1.15:3000/reset-password?token=" + token;
        
        String subject = "Password Reset Request";
        String body = "You requested a password reset.\n\n"
                    + "You can reset your password using one of the links below:\n\n"
                    + "Localhost: " + resetLink1 + "\n"
                    + "Network: " + resetLink2 + "\n\n"
                    + "If you did not request this, please ignore this email.";

        // Send the email using the EmailService
        emailService.sendEmail(email, subject, body);
    }


    private void generateResetTokenForUser(Admin admin) {
        String token = UUID.randomUUID().toString();
        admin.setResetToken(token);
        adminRepository.save(admin);
        sendResetEmail(admin.getEmail(), token);
    }

    private void generateResetTokenForUser(Mentor mentor) {
        String token = UUID.randomUUID().toString();
        mentor.setResetToken(token);
        mentorRepository.save(mentor);
        sendResetEmail(mentor.getEmail(), token);
    }

    private void generateResetTokenForUser(Student student) {
        String token = UUID.randomUUID().toString();
        student.setResetToken(token);
        studentRepository.save(student);
        sendResetEmail(student.getEmail(), token);
    }


    // ✅ 5️⃣ Reset Password Using Token
    public void resetPassword(String token, String newPassword) {
        // Check if the token exists for any model (Admin, Mentor, or Student)
        Optional<Admin> adminOpt = adminRepository.findByResetToken(token);
        if (adminOpt.isPresent()) {
            resetPasswordForUser(adminOpt.get(), newPassword);
            return;
        }

        Optional<Mentor> mentorOpt = mentorRepository.findByResetToken(token);
        if (mentorOpt.isPresent()) {
            resetPasswordForUser(mentorOpt.get(), newPassword);
            return;
        }

        Optional<Student> studentOpt = studentRepository.findByResetToken(token);
        if (studentOpt.isPresent()) {
            resetPasswordForUser(studentOpt.get(), newPassword);
            return;
        }

        // If the token doesn't exist in any model
        throw new RuntimeException("❌ Invalid or expired token.");
    }

    private void resetPasswordForUser(Object user, String newPassword) {
        // Reset password logic
        if (user instanceof Admin) {
            Admin admin = (Admin) user;
            admin.setPassword(passwordEncoder.encode(newPassword));  // 🔹 Encrypt the password
            admin.setResetToken(null);
            adminRepository.save(admin);
        } else if (user instanceof Mentor) {
            Mentor mentor = (Mentor) user;
            mentor.setPassword(passwordEncoder.encode(newPassword));  // 🔹 Encrypt the password
            mentor.setResetToken(null);
            mentorRepository.save(mentor);
        } else if (user instanceof Student) {
            Student student = (Student) user;
            student.setPassword(passwordEncoder.encode(newPassword));  // 🔹 Encrypt the password
            student.setResetToken(null);
            studentRepository.save(student);
        }

        System.out.println("✅ Password reset successfully.");
    }
}
