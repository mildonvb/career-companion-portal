package com.example.Mildon.service;

import com.example.Mildon.model.MockInterview;
import com.example.Mildon.model.Student;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.repository.MockInterviewRepository;
import com.example.Mildon.repository.StudentRepository;
import com.example.Mildon.repository.MentorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MockInterviewService {

    @Autowired
    private MockInterviewRepository mockInterviewRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private MentorRepository mentorRepository;

    public List<MockInterview> getMockInterviewsByStudent(Long studentId) {
        return mockInterviewRepository.findByStudentId(studentId);
    }

    public List<MockInterview> getMockInterviewsByMentor(Long mentorId) {
        return mockInterviewRepository.findByMentorId(mentorId);
    }

    public MockInterview updateInterviewStatus(Long interviewId, String status, String roomId) {
        MockInterview interview = mockInterviewRepository.findById(interviewId)
                .orElseThrow(() -> new RuntimeException("Mock Interview not found"));

        interview.setStatus(status);
        if ("Accepted".equals(status)) {
            interview.setRoomId(roomId);
        }

        return mockInterviewRepository.save(interview);
    }
}
