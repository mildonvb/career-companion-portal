package com.example.Mildon.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.Mildon.model.Admin;
import com.example.Mildon.repository.AdminRepository;

@Component
public class AdminInitializer implements CommandLineRunner {

    @Autowired
    private AdminRepository adminRepository;  // Assuming you have a repository for Admin

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        String email = "admin@example.com";
        if (!adminRepository.existsByEmail(email)) {
            Admin admin = new Admin();
            admin.setEmail(email);
            admin.setFullName("Super Admin");
            admin.setPassword(passwordEncoder.encode("admin123")); // Change this password
            adminRepository.save(admin);
            System.out.println("✅ Default Admin Created!");
        } else {
            System.out.println("✅ Admin Already Exists");
        }
    }
}
