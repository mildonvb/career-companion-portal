package com.example.Mildon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Resume;
import com.example.Mildon.model.Student;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.ResumeRepository;
import com.example.Mildon.repository.StudentMentorRepository;
import com.example.Mildon.repository.StudentRepository;

import jakarta.transaction.Transactional;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ResumeService {
    @Autowired
    private ResumeRepository resumeRepository;
    
    @Autowired
    private MentorRepository mentorRepository;
    
    @Autowired
    private StudentMentorRepository studentMentorRepository;
    
    @Autowired
    private StudentRepository studentRepository;

    // Upload Resume
    public Resume uploadResume(Long studentId, MultipartFile file) throws IOException {
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found"));

        // Fetch mentorId from student_mentor table
        Long mentorId = studentMentorRepository.findMentorIdByStudentId(studentId)
            .orElseThrow(() -> new RuntimeException("Mentor not assigned"));

        Resume resume = new Resume();
        resume.setStudent(student);
        resume.setMentorId(mentorId); // Store mentorId
        resume.setFileData(file.getBytes());
        resume.setFileType(file.getContentType());
        resume.setFileName(file.getOriginalFilename());
        resume.setValidated(false);
        resume.setFeedback(null);

        return resumeRepository.save(resume);
    }


    // ✅ Get all resumes uploaded by a specific student
    public List<Resume> getStudentResumes(Long studentId) {
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found"));

        return resumeRepository.findAll().stream()
            .filter(resume -> resume.getStudent().getId().equals(studentId))
            .collect(Collectors.toList());
    }

    // Get Resumes of Students Assigned to a Mentor
    public List<Resume> getAssignedStudentsResumes(Long mentorId) {
        Mentor mentor = mentorRepository.findById(mentorId)
            .orElseThrow(() -> new RuntimeException("Mentor not found"));

        // ✅ Fetch students assigned to this mentor from StudentMentorRepository
        List<Student> assignedStudents = studentMentorRepository.findStudentsByMentorId(mentorId);

        return resumeRepository.findAll()
            .stream()
            .filter(resume -> assignedStudents.contains(resume.getStudent()))
            .collect(Collectors.toList());
    }
    
   

    public List<Resume> getResumesForMentor(Long mentorId) {
        return resumeRepository.findResumesByMentorId(mentorId);
    }

    // Mentor Provides Feedback on Resume
    public Resume validateResume(Long resumeId, String feedback) {
        Resume resume = resumeRepository.findById(resumeId)
            .orElseThrow(() -> new RuntimeException("Resume not found"));

        resume.setValidated(true);
        resume.setFeedback(feedback);
        
        return resumeRepository.save(resume);
    }
    @Transactional
    public void provideFeedback(Long resumeId, String feedback) {
        Resume resume = resumeRepository.findById(resumeId)
            .orElseThrow(() -> new ResourceNotFoundException("Resume not found"));

        resume.setFeedback(feedback);
        resumeRepository.save(resume);
    }


}
