package com.example.Mildon.dto;

public class AuthenticationResponse {
    private String token;
    private Long userId;
    private String username;
    private String role;

    public AuthenticationResponse(String token, Long userId, String username, String role) {
        this.token = token;
        this.userId = userId;
        this.username = username;
        this.role = role;
    }

    // Getters and setters
}
