//package com.example.Mildon.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.stereotype.Service;
//
//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    public void sendEmail(String to, String subject, String text) {
//        try {
//            System.out.println("Attempting to send email to: " + to);
//            
//            SimpleMailMessage message = new SimpleMailMessage();
//            message.setTo(to);
//            message.setSubject(subject);
//            message.setText(text);
//            mailSender.send(message);
//
//            System.out.println("Email sent successfully to: " + to);
//        } catch (Exception e) {
//            System.out.println("Error sending email: " + e.getMessage());
//        }
//    }
//
//}

package com.example.Mildon.service;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendEmail(String to, String subject, String text) {
        try {
            MimeMessageHelper message = new MimeMessageHelper(javaMailSender.createMimeMessage());
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            javaMailSender.send(message.getMimeMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
