package com.example.Mildon.repository;

import com.example.Mildon.model.MockInterview;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MockInterviewRepository extends JpaRepository<MockInterview, Long> {
    List<MockInterview> findByStudentId(Long studentId);
    List<MockInterview> findByMentorId(Long mentorId);
}
