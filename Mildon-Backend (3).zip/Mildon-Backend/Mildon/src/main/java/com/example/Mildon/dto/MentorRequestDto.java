package com.example.Mildon.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MentorRequestDto {
    private String fullName;
    private String email;
    private String password;
    private String specialization;
    public MentorRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MentorRequestDto(String fullName, String email, String password, String specialization, String availability,
			String phoneNumber, int experience, String linkedInProfile) {
		super();
		this.fullName = fullName;
		this.email = email;
		this.password = password;
		this.specialization = specialization;
		this.availability = availability;
		this.phoneNumber = phoneNumber;
		this.experience = experience;
		this.linkedInProfile = linkedInProfile;
	}
	@Override
	public String toString() {
		return "MentorRequestDto [fullName=" + fullName + ", email=" + email + ", password=" + password
				+ ", specialization=" + specialization + ", availability=" + availability + ", phoneNumber="
				+ phoneNumber + ", experience=" + experience + ", linkedInProfile=" + linkedInProfile + "]";
	}
	private String availability;
    private String phoneNumber;
    private int experience;
    private String linkedInProfile;
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getLinkedInProfile() {
		return linkedInProfile;
	}
	public void setLinkedInProfile(String linkedInProfile) {
		this.linkedInProfile = linkedInProfile;
	}
}
