//package com.example.Mildon.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.example.Mildon.model.Admin;
//import com.example.Mildon.model.Mentor;
//import com.example.Mildon.model.Student;
//import com.example.Mildon.service.AdminService;
//import com.example.Mildon.service.MentorService;
//import com.example.Mildon.service.StudentService;
//import com.example.Mildon.dto.ForgotPasswordRequest;
//import com.example.Mildon.dto.ResetPasswordRequest;
//import com.example.Mildon.dto.ResponseMessage;
//import com.example.Mildon.service.EmailService;
//
//import java.util.*;
//
//@RestController
//@RequestMapping("/api/auth")
//@CrossOrigin(origins = "http://localhost:3000")
//public class AuthController {
//          
//    @Autowired
//    private StudentService studentService;
//    
//    @Autowired
//    private MentorService mentorService;
//    
//    @Autowired
//    private AdminService adminService;
//    
//    @Autowired
//    private EmailService emailService;
//
//    // ✅ REGISTER NEW USER (Student, Mentor, Admin)
//    @PostMapping("/signup/student")
//    public ResponseEntity<?> registerStudent(@RequestBody Student student) {
//        if (studentService.existsByEmail(student.getEmail())) {
//            return ResponseEntity.badRequest().body("Email already exists!");
//        }
//        Student savedStudent = studentService.registerStudent(student);
//        return ResponseEntity.ok(savedStudent);
//    }
//
//    @PostMapping("/signup/mentor")
//    public ResponseEntity<?> registerMentor(@RequestBody Mentor mentor) {
//        if (mentorService.existsByEmail(mentor.getEmail())) {
//            return ResponseEntity.badRequest().body("Email already exists!");
//        }
//        Mentor savedMentor = mentorService.registerMentor(mentor);
//        return ResponseEntity.ok(savedMentor);
//    }
//
//    @PostMapping("/signup/admin")
//    public ResponseEntity<?> registerAdmin(@RequestBody Admin admin) {
//        if (adminService.existsByEmail(admin.getEmail())) {
//            return ResponseEntity.badRequest().body("Email already exists!");
//        }
//        Admin savedAdmin = adminService.registerAdmin(admin);
//        return ResponseEntity.ok(savedAdmin);
//    }
//
//    // ✅ LOGIN: Search across all user tables
//    @PostMapping("/login")
//    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> credentials) {
//        String email = credentials.get("email");
//        String password = credentials.get("password");
//
//        Object user = null;
//        String role = null;
//
//        if (studentService.existsByEmail(email)) {
//            user = studentService.loginStudent(email, password);
//            role = "STUDENT";
//        } else if (mentorService.existsByEmail(email)) {
//            user = mentorService.loginMentor(email, password);
//            role = "MENTOR";
//        } else if (adminService.existsByEmail(email)) {
//            user = adminService.loginAdmin(email, password);
//            role = "ADMIN";
//        }
//
//        if (user == null) {
//            return ResponseEntity.status(401).body(Map.of("message", "Invalid Credentials"));
//        }
//
//        Map<String, Object> response = new HashMap<>();
//        response.put("role", role);
//        response.put("email", email);
//
//        return ResponseEntity.ok(response);
//    }
//
//    // ✅ FORGOT PASSWORD (Send Reset Email)
//    @PostMapping("/forgot-password")
//    public ResponseEntity<ResponseMessage> forgotPassword(@RequestBody ForgotPasswordRequest request) {
//        try {
//            emailService.sendEmail(request.getEmail(), "Password Reset", "Click the link to reset password...");
//            return ResponseEntity.ok(new ResponseMessage("Password reset link sent to your email."));
//        } catch (RuntimeException e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(e.getMessage()));
//        }
//    }
//
//    // ✅ RESET PASSWORD
//    @PostMapping("/reset-password")
//    public ResponseEntity<ResponseMessage> resetPassword(@RequestBody ResetPasswordRequest request) {
//        try {
//            // Implement reset logic in the respective service
//            return ResponseEntity.ok(new ResponseMessage("Password reset successfully."));
//        } catch (RuntimeException e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(e.getMessage()));
//        }
//    }
//
//    // ✅ GET ALL MENTORS
//    @GetMapping("/mentors")
//    public ResponseEntity<List<Mentor>> getMentors() {
//        List<Mentor> mentors = mentorService.getAllMentors();
//        return ResponseEntity.ok(mentors);
//    }
//
//    // ✅ DELETE A MENTOR
//    @DeleteMapping("/mentors/{id}")
//    public ResponseEntity<String> deleteMentor(@PathVariable Long id) {
//        boolean deleted = mentorService.deleteMentorById(id);
//        if (deleted) {
//            return ResponseEntity.ok("Mentor deleted successfully");
//        }
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Mentor not found");
//    }
//
//    // ✅ GET ALL STUDENTS
//    @GetMapping("/students")
//    public ResponseEntity<List<Student>> getStudents() {
//        List<Student> students = studentService.getAllStudents();
//        return ResponseEntity.ok(students);
//    }
//
//    // ✅ DELETE A STUDENT
//    @DeleteMapping("/students/{id}")
//    public ResponseEntity<String> deleteStudent(@PathVariable Long id) {
//        boolean deleted = studentService.deleteStudentById(id);
//        if (deleted) {
//            return ResponseEntity.ok("Student deleted successfully");
//        }
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
//    }
//}
