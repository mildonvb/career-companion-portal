package com.example.Mildon.service;

import com.example.Mildon.dto.MentorRequestDto;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.StudentMentorRepository;
import com.example.Mildon.repository.StudentRepository;

import java.util.Collections;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class MentorService {
    private final MentorRepository mentorRepository;
    private final PasswordEncoder passwordEncoder;

    public MentorService(MentorRepository mentorRepository, PasswordEncoder passwordEncoder) {
        this.mentorRepository = mentorRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Mentor registerMentor(MentorRequestDto request) {
        if (mentorRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Mentor with this email already exists!");
        }

        Mentor mentor = new Mentor();
        mentor.setFullName(request.getFullName());
        mentor.setEmail(request.getEmail());
        mentor.setPassword(passwordEncoder.encode(request.getPassword())); // Encrypt password
        mentor.setSpecialization(request.getSpecialization());
        mentor.setAvailability(request.getAvailability());
        mentor.setPhoneNumber(request.getPhoneNumber());
//        mentor.setExperience(request.getExperience());
//        mentor.setLinkedInProfile(request.getLinkedInProfile());

        return mentorRepository.save(mentor);
    }
    
    
    

    public List<Mentor> getAllMentors() {
        return mentorRepository.findAll();
    }

    public List<Mentor> searchMentors(String fullName, String specialization) {
        return mentorRepository.findByFullNameContainingAndSpecializationContaining(fullName, specialization);
    }
 
    // Method to get Mentor by ID
    public Mentor getMentorById(Long id) {
        Optional<Mentor> mentor = mentorRepository.findById(id);
        return mentor.orElse(null); // Returns null if not found (or you can throw an exception)
    }
    
    public void updateMentor(Long id, Mentor updatedMentor) {
        Mentor existingMentor = mentorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Mentor not found with ID: " + id));

        // Update mentor details
        existingMentor.setFullName(updatedMentor.getFullName());
        existingMentor.setEmail(updatedMentor.getEmail());

        existingMentor.setPhoneNumber(updatedMentor.getPhoneNumber());
        existingMentor.setSpecialization(updatedMentor.getSpecialization());
        existingMentor.setAvailability(updatedMentor.getAvailability());

        mentorRepository.save(existingMentor); // Save the updated mentor
    }
    public void deleteMentor(Long id) {
        mentorRepository.deleteById(id);
    }
    
    
    
    
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private StudentMentorRepository studentMentorRepository; // Repository for student_mentor table

    public List<Student> getAssignedStudents(Long mentorId) {
        List<Long> studentIds = studentMentorRepository.findStudentIdsByMentorId(mentorId);
        if (studentIds.isEmpty()) {
            return Collections.emptyList(); // Return an empty list if no students are assigned
        }
        return studentRepository.findAllById(studentIds);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}