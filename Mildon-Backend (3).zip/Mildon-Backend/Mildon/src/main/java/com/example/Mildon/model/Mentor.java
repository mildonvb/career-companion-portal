package com.example.Mildon.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Entity
@Table(name = "mentors")
public class Mentor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String specialization;

    @Column(nullable = false)
    private String availability;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(name = "reset_token")
    private String resetToken;

//    private int experience;
//    private String linkedInProfile;
    
    public String getResetToken() {
		return resetToken;
	}


	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}


	public Long getId() {
        return id;
    }


    public void setId(Long id) {
		this.id = id;
	}


	// ✅ Default constructor (Fixes "The constructor Mentor() is undefined")
    public Mentor() {}

    // ✅ Getters and Setters (Lombok alternative if needed)
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getAvailability() { return availability; }
    public void setAvailability(String availability) { this.availability = availability; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

//    public int getExperience() { return experience; }
//    public void setExperience(int experience) { this.experience = experience; }
//
//    public String getLinkedInProfile() { return linkedInProfile; }
//    public void setLinkedInProfile(String linkedInProfile) { this.linkedInProfile = linkedInProfile; }
}

