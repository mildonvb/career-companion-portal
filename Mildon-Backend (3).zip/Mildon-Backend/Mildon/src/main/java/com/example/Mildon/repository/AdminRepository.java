package com.example.Mildon.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.Mildon.model.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
	Admin findByEmail(String email);
	boolean existsByEmail(String email);  // ✅ Add this method
	Optional<Admin> findByResetToken(String resetToken);

}
