//package com.example.Mildon.controller;
//
//import com.example.Mildon.dto.LoginRequest;
//import com.example.Mildon.security.JwtTokenUtil;
//import com.example.Mildon.dto.JwtResponse;
//import com.example.Mildon.security.CustomUserDetailsService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/auth")
//public class LoginController {
//
//    @Autowired
//    private AuthenticationManager authenticationManager;
//
//    @Autowired
//    private JwtTokenUtil jwtTokenUtil;
//
//    @Autowired
//    private CustomUserDetailsService userDetailsService;
//
//    // Login API
//    @PostMapping("/login")
//    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
//
//        String email = loginRequest.getEmail();
//        String password = loginRequest.getPassword();
//        String role = loginRequest.getRole(); // Role: admin, mentor, student
//
//        // Authenticate based on the email and password
//        UserDetails userDetails = userDetailsService.loadUserByUsername(email);
//
//        if (!userDetails.getPassword().equals(password)) {
//            return ResponseEntity.status(401).body("Invalid credentials");
//        }
//
//        // Create authentication token
//        Authentication authentication = authenticationManager.authenticate(
//                new UsernamePasswordAuthenticationToken(email, password)
//        );
//
//        // Set the authentication in the security context
//        SecurityContextHolder.getContext().setAuthentication(authentication);
//
//        // Generate JWT token for the authenticated user
//        String jwt = jwtTokenUtil.generateToken(authentication);
//
//        // Return JWT token in response
//        return ResponseEntity.ok(new JwtResponse(jwt));
//    }
//}
