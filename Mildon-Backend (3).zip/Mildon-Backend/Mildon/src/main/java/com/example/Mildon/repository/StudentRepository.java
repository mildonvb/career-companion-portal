package com.example.Mildon.repository;

import com.example.Mildon.model.Student;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    boolean existsByEmail(String email);  // Check if email exists
    Student findByEmail(String email);
    List<Student> findByMentorIdIsNull();
    Optional<Student> findByResetToken(String resetToken);
    List<Student> findAll();  // Ensure this is present


}

