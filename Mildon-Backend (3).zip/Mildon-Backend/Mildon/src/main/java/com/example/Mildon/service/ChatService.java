package com.example.Mildon.service;

import com.example.Mildon.model.ChatMessage;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.repository.ChatMessageRepository;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.StudentMentorRepository;
import com.example.Mildon.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ChatService {

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @Autowired
    private StudentMentorRepository studentMentorRepository;

    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private StudentRepository studentRepository;

    public ChatMessage saveMessage(ChatMessage message) {
        System.out.println("Saving Message:");
        System.out.println("Sender: " + message.getSenderId());
        System.out.println("Receiver: " + message.getReceiverId());
        System.out.println("Content: " + message.getContent());

        if (message.getSenderId() == null || message.getReceiverId() == null) {
            throw new IllegalArgumentException("Sender and Receiver must not be null");
        }

        message.setTimestamp(LocalDateTime.now());
        return chatMessageRepository.save(message);
    }


    public List<ChatMessage> getMessagesBetweenUsers(String senderId, String receiverId) {
        return chatMessageRepository.findBySenderIdAndReceiverId(senderId, receiverId);
    }

    public List<Student> getStudentsForMentor(String mentorId) {
        Long id = Long.parseLong(mentorId);
        return studentMentorRepository.findStudentsByMentorId(id);
    }

    public Mentor getMentorForStudent(String studentId) {
        Long id = Long.parseLong(studentId);
        Optional<Long> mentorId = studentMentorRepository.findMentorIdByStudentId(id);
        return mentorId.flatMap(mid -> mentorRepository.findById(mid)).orElse(null);
    }
    
}
