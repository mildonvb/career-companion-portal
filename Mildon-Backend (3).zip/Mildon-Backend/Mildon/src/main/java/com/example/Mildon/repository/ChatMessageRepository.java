package com.example.Mildon.repository;

import com.example.Mildon.model.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    List<ChatMessage> findBySenderIdAndReceiverId(String senderId, String receiverId);
    List<ChatMessage> findBySenderIdOrReceiverId(String senderId, String receiverId);
}
