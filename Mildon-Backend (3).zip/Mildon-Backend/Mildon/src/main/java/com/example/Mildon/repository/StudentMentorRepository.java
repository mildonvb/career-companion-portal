package com.example.Mildon.repository;

import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.model.StudentMentor;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentMentorRepository extends JpaRepository<StudentMentor, Long> {
    StudentMentor findByStudentIdAndMentorId(Long studentId, Long mentorId);
    @Modifying
    @Transactional
    @Query("UPDATE Student s SET s.mentor = :mentor WHERE s.id = :studentId")
    void updateStudentMentor(@Param("studentId") Long studentId, @Param("mentor") Mentor mentor);

    @Modifying
    @Transactional
    @Query("DELETE FROM StudentMentor sm WHERE sm.student.id = :studentId")
    void deleteByStudentId(@Param("studentId") Long studentId);
    Optional<StudentMentor> findByStudentId(Long studentId);
    
    @Query("SELECT sm.student.id FROM StudentMentor sm WHERE sm.mentor.id = :mentorId")
    List<Long> findStudentIdsByMentorId(@Param("mentorId") Long mentorId);

    @Query("SELECT s FROM Student s JOIN StudentMentor sm ON s.id = sm.student.id WHERE sm.mentor.id = :mentorId")
    List<Student> findStudentsByMentorId(@Param("mentorId") Long mentorId);

    @Query("SELECT sm.mentor.id FROM StudentMentor sm WHERE sm.student.id = :studentId")
    Optional<Long> findMentorIdByStudentId(@Param("studentId") Long studentId);
    
    
}
