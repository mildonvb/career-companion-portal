package com.example.Mildon.controller;

import com.example.Mildon.model.MockInterview;
import com.example.Mildon.model.StudentMentor;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.repository.MockInterviewRepository;
import com.example.Mildon.repository.StudentMentorRepository;
import com.example.Mildon.service.MockInterviewService;
import com.example.Mildon.service.ResourceNotFoundException;
import com.example.Mildon.dto.MockInterviewRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/mock-interviews")
@CrossOrigin(origins = "*")

public class MockInterviewController {

    @Autowired
    private MockInterviewService mockInterviewService;

    @Autowired
    private MockInterviewRepository mockInterviewRepository;

    @Autowired
    private StudentMentorRepository studentMentorRepository;

    @PostMapping("/request")
    public ResponseEntity<?> requestMockInterview(@RequestBody MockInterviewRequest request) {
        Optional<StudentMentor> studentMentor = studentMentorRepository.findByStudentId(request.getStudentId());

        if (studentMentor.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No mentor assigned to this student.");
        }

        Mentor assignedMentor = studentMentor.get().getMentor();

        MockInterview interview = new MockInterview();
        interview.setStudentId(request.getStudentId());
        interview.setMentor(assignedMentor);
        interview.setStatus("Requested");
        interview.setRoomId(null);

        mockInterviewRepository.save(interview);
        return ResponseEntity.ok("Mock interview requested successfully.");
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<MockInterview>> getMockInterviewsByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(mockInterviewService.getMockInterviewsByStudent(studentId));
    }

    @GetMapping("/mentor/{mentorId}")
    public ResponseEntity<List<MockInterview>> getMockInterviewsByMentor(@PathVariable Long mentorId) {
        return ResponseEntity.ok(mockInterviewService.getMockInterviewsByMentor(mentorId));
    }

    @PutMapping("/update-status/{interviewId}")
    public ResponseEntity<MockInterview> updateInterviewStatus(
            @PathVariable Long interviewId,
            @RequestBody Map<String, String> request) {

        String status = request.get("status");
        String roomId = request.get("roomId");

        MockInterview updatedInterview = mockInterviewService.updateInterviewStatus(interviewId, status, roomId);
        return ResponseEntity.ok(updatedInterview);
    }

    @PutMapping("/accept/{interviewId}")
    public ResponseEntity<?> acceptMockInterview(
            @PathVariable Long interviewId,
            @RequestHeader("userId") Long mentorId) {

        MockInterview interview = mockInterviewRepository.findById(interviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Mock interview not found"));

        if (!interview.getMentor().getId().equals(mentorId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You are not assigned to this interview.");
        }

        if (interview.getRoomId() == null) {
            interview.setRoomId(UUID.randomUUID().toString());
        }

        interview.setStatus("Accepted");
        mockInterviewRepository.save(interview);

        return ResponseEntity.ok(Map.of(
                "message", "Mock interview accepted successfully.",
                "roomId", interview.getRoomId()
        ));
    }

    @GetMapping("/{studentId}/mentor")
    public ResponseEntity<Map<String, Object>> getAssignedMentor(@PathVariable Long studentId) {
        Optional<StudentMentor> studentMentor = studentMentorRepository.findByStudentId(studentId);
        
        if (studentMentor.isPresent()) {
            Map<String, Object> response = new HashMap<>();
            response.put("mentorId", studentMentor.get().getMentor().getId());
            response.put("mentorName", studentMentor.get().getMentor().getFullName());
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "No mentor assigned.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

}
