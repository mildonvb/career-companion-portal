package com.example.Mildon.service;

import com.example.Mildon.dto.StudentDTO;
import com.example.Mildon.model.Mentor;
import com.example.Mildon.model.Student;
import com.example.Mildon.model.StudentMentor;
import com.example.Mildon.repository.MentorRepository;
import com.example.Mildon.repository.StudentMentorRepository;
import com.example.Mildon.repository.StudentRepository;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    
    

    private final BCryptPasswordEncoder passwordEncoder;

    // Constructor to initialize BCryptPasswordEncoder
    public StudentService() {
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    public boolean registerStudent(Student student) {
        try {
            // Hash the password before saving to the database
            String hashedPassword = passwordEncoder.encode(student.getPassword());
            student.setPassword(hashedPassword);  // Set the hashed password

            // Save the student to the database
            studentRepository.save(student);
            return true; // Successfully saved
        } catch (Exception e) {
            // Log exception and return false
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean isValidStudent(String email) {
        return studentRepository.existsByEmail(email);  // Adjust this according to your repository's method
    }
    
    
    
    
    
 

    @Autowired
    private MentorRepository mentorRepository;

    public List<Student> getUnassignedStudents() {
        return studentRepository.findByMentorIdIsNull(); // Custom query to get unassigned students
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }



    @Transactional
    public void removeMentor(Long studentId) {
        // Check if student exists
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new IllegalArgumentException("❌ Student not found"));

        // Remove mentor assignment
        student.setMentor(null);
        studentRepository.save(student);

        // Delete the student-mentor entry in `student_mentor` table
        studentMentorRepository.findByStudentId(studentId).ifPresent(studentMentorRepository::delete);
    }


    
    @Autowired
    private StudentMentorRepository studentMentorRepository; 
// Inject the repository for the student_mentor table

    @Transactional
    public Student assignOrUpdateMentor(Long studentId, Long mentorId) {
        // Step 1: Check if student exists
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new IllegalArgumentException("❌ Student not found"));

        // Step 2: Check if mentor exists
        Mentor mentor = mentorRepository.findById(mentorId)
            .orElseThrow(() -> new IllegalArgumentException("❌ Mentor not found"));

        // Step 3: Check if the student already has a mentor
        Optional<StudentMentor> existingAssignment = studentMentorRepository.findByStudentId(studentId);
        
        if (existingAssignment.isPresent()) {
            // Step 4: If a mentor is already assigned, update it
            StudentMentor studentMentor = existingAssignment.get();
            studentMentor.setMentor(mentor);
            studentMentorRepository.save(studentMentor);
        } else {
            // Step 5: If no mentor is assigned, create a new assignment
            StudentMentor studentMentor = new StudentMentor();
            studentMentor.setStudent(student);
            studentMentor.setMentor(mentor);
            studentMentorRepository.save(studentMentor);
        }

        // Step 6: Update the mentor reference in the Student entity
        student.setMentor(mentor);
        studentRepository.save(student);

        return student;
    }


    // Get student by ID
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }
    
    public Student updateStudent(Long id, Student updatedStudent) {
        return studentRepository.findById(id).map(student -> {
            student.setFullName(updatedStudent.getFullName());
            student.setEmail(updatedStudent.getEmail());
            student.setPhone(updatedStudent.getPhone());
            return studentRepository.save(student);
        }).orElse(null);
    }

    // Delete student by ID
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
}
 
    public List<StudentDTO> getAllStudentsWithMentors() {
        List<Student> students = studentRepository.findAll();

        return students.stream()
            .map(student -> new StudentDTO(
                student.getId(),
                student.getFullName(),
                student.getEmail(),
                student.getPhone(),
                student.getMentor() != null ? student.getMentor().getFullName() : "Not Assigned"
            ))
            .collect(Collectors.toList());
    }
    
}
