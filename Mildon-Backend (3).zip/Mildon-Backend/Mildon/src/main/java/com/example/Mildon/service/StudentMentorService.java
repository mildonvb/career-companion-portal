//package com.example.Mildon.service;
//
//import com.example.Mildon.model.Student;
//import com.example.Mildon.model.Mentor;
//import com.example.Mildon.model.StudentMentor;
//import com.example.Mildon.repository.StudentMentorRepository;
//import com.example.Mildon.repository.StudentRepository;
//import com.example.Mildon.repository.MentorRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.Optional;
//
//@Service
//public class StudentMentorService {
//    @Autowired
//    private StudentMentorRepository studentMentorRepository;
//
//    @Autowired
//    private StudentRepository studentRepository;
//
//    @Autowired
//    private MentorRepository mentorRepository;
//
//    public String assignMentor(Long studentId, Long mentorId) {
//        Optional<Student> studentOpt = studentRepository.findById(studentId);
//        Optional<Mentor> mentorOpt = mentorRepository.findById(mentorId);
//
//        if (studentOpt.isPresent() && mentorOpt.isPresent()) {
//            StudentMentor assignment = new StudentMentor(studentOpt.get(), mentorOpt.get());
//            studentMentorRepository.save(assignment);
//            return "Mentor assigned successfully!";
//        } else {
//            return "Student or Mentor not found!";
//        }
//    }
//}
