package com.example.Mildon.repository;

import com.example.Mildon.model.Resume;
import com.example.Mildon.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ResumeRepository extends JpaRepository<Resume, Long> {
    Optional<Resume> findByStudent(Student student);
    List<Resume> findByStudentId(Long studentId);
    @Query("SELECT r FROM Resume r WHERE r.mentorId = :mentorId")
    List<Resume> findResumesByMentorId(@Param("mentorId") Long mentorId);
}
